import type { IServer } from '../typings/IServer';
import type { Express, Request, Response, RequestHandler, Application, Router } from 'express';
import type { Server as NodeServer } from 'http';

import { Trace } from '@soprabanking/core/lib/Trace';

import http from 'http';
import https from 'https';
import express from 'express';
import logger from 'morgan';

import Ping from './Ping';
import MiddlewareUtils from './MiddlewareUtils';

export const createApp = express;

export type { Express, Request, Response, RequestHandler, Application, Router, IServer };
export * from './HttpError';

const isProduction = process.env.NODE_ENV === 'production';

export class Server implements IServer.Definition {
  readonly options: IServer.Options;
  server!: NodeServer;

  static readonly parse = {
    /**
     * Parse incoming requests with JSON payloads and is based on body-parser
     */
    json: express.json,
    /**
     * Parse incoming requests with Buffer payloads and is based on body-parser
     */
    raw: express.raw,
    /**
     * Parse incoming requests with text payloads and is based on body-parser
     */
    text: express.text,
    /**
     * Parse incoming requests with urlencoded payloads and is based on body-parser
     */
    urlencoded: express.urlencoded,
  };

  static createRouter(): Router {
    return express.Router({
      strict: true,
      caseSensitive: false,
    });
  }

  constructor(options: IServer.Options) {
    options.name = options.name.split('/').reverse()[0];

    this.options = options;
  }

  protected async _start(): Promise<void> {
    const app: Express = createApp();
    const loggerFormat = isProduction
      ? `:date[iso] ${this.options.name} HTTP - :remote-addr - :remote-user ":method :url HTTP/:http-version" :status :res[content-length] ":referrer" ":user-agent"`
      : `:date[iso] ${this.options.name} HTTP - :method :url :status :response-time ms - :res[content-length]`;

    Trace.info(`Setting ${this.options.name} server...`);
    app.disable('x-powered-by');

    app.use(logger(loggerFormat));

    app.route('/status')
      .head((req, res) => res.sendStatus(200))
      .get((req, res) => res.json({
        name: this.options.name,
        version: this.options.version,
        status: 'up',
        uptime: process.uptime(),
      }));

    app.set('port', this.options.port);

    await this._prepare();

    if (this.options.beforeStart) {
      try {
        await this.options.beforeStart(this);
      } catch (err: any) {
        Trace.error('Failed to initialize server');

        if (err.message) {
          Trace.error(err.message);
        }

        Trace.error(`${err.stack}`);

        process.exit(-6);
      }
    }

    this.options.loader(app);

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    app.use((err: Error, req: Request, res: Response, next: () => void) => MiddlewareUtils.handleError(err, res));

    this.server = this.options.certificat
      ? https.createServer(this.options.certificat, app)
      : http.createServer(app);

    this.server.on('error', (error: any) => {
      if (error.syscall !== 'listen') {
        throw error;
      }

      // handle specific listen errors with friendly messages
      switch (error.code) {
        case 'EACCES':
          Trace.error(`${this.options.port} requires elevated privileges`);
          process.exit(-3);

        case 'EADDRINUSE':
          Trace.error(`${this.options.port} is already in use`);
          process.exit(-4);

        default:
          throw error;
      }
    });

    this.server.on('listening', () => Trace.info(`Listening on ${this.options.port}`));
    Trace.info(`Starting ${this.options.name} server...`);
    this.server.listen(this.options.port, '0.0.0.0');
  }

  protected async _prepare(): Promise<void> {}

  async start(): Promise<void> {
    process.on('SIGINT', () => this.server.close(() => process.exit(0)));

    if (this.options.serviceDependencies instanceof Array) {
      try {
        await Ping.checkAll(this.options.serviceDependencies, {
          timeout: 5000,
          interval: isProduction ? 10000 : 3000,
          retries: isProduction ? 10 : Number.MAX_SAFE_INTEGER,
        });
      } catch (err: any) {
        Trace.error(err.message);
        Trace.error('Starting aborted');

        process.exit(-5);
      }
    }

    await this._start();
  }
}
