import { Response } from 'express';
import { HttpError } from './HttpError';
import { Trace } from '@soprabanking/core/lib/Trace';

export type InternalError = Error & {
  [key: string]: any;
};

export default {
  handleError(err: InternalError, res: Response): void {
    if (err instanceof HttpError) {
      res.status(err.statusCode);

      if (err.body) {
        res.json(err.body);
        Trace.error(`${err.statusCode} - Body: ${JSON.stringify(err.body)}`);
      } else {
        res.end();
        Trace.error(`${err.statusCode} - ${err.message}`);
      }
    } else if (err.statusCode) {
      res.sendStatus(err.statusCode);
      Trace.error(`${err.statusCode} - ${err.message}`);
    } else if (err.status) {
      res.sendStatus(err.status);
      Trace.error(`${err.status} - ${err.message}`);
    } else {
      res.sendStatus(500);
      Trace.error(`500 - ${err.message} - ${err.stack}`);
    }
  },
};
