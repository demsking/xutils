export * from './IClient';

/**
 * Get object keys as union
 */
export type KeysUnion<T> = ObjectKeysTree<T>[keyof ObjectKeysTree<T>];

export type KeysArray<T> = {
  [P in keyof T]-?: [P];
};

type ObjectKeysTree<T> = {
  [P in keyof T]-?: P;
};
