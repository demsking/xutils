import fs from 'fs/promises';
import path from 'path/posix';
import YAML from 'yaml';
import { Trace } from './Trace';

export const FS = {
  TEMPDIR: '/tmp',
  BASEDIR: process.cwd(),
};

export async function mkdirp(dir: string) {
  const realpath = path.isAbsolute(dir) ? dir : path.join(FS.BASEDIR, dir);

  await fs.mkdir(realpath, { recursive: true });
}

export async function writeFile(filename: string, data: object) {
  const realpath = path.isAbsolute(filename) ? filename : path.join(FS.BASEDIR, filename);

  Trace.log(`Writing ${realpath}`);

  await fs.writeFile(realpath, YAML.stringify(data));
}

export async function readYaml<T>(filename: string, multiDocument = false): Promise<T> {
  const realpath = path.isAbsolute(filename) ? filename : path.join(FS.BASEDIR, filename);

  Trace.log(`Reading ${realpath}`);

  const content = await fs.readFile(realpath, 'utf8');

  return multiDocument
    ? YAML.parseAllDocuments(content).map((doc) => doc.toJSON())
    : YAML.parseDocument(content).toJSON();
}
