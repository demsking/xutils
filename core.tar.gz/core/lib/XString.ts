export const XString = {
  parseCamelCase(str: string, separator = ' ') {
    const lowercase = str.toLowerCase();
    const chars = [];

    for (let i = 0; i < str.length; i++) {
      const charLower = lowercase.charAt(i);
      const charString = str.charAt(i);

      if (charString !== charLower) {
        chars.push(separator);
      }

      chars.push(charLower);
    }

    return chars.join('');
  },
};
