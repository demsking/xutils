export const XArray = {
  remove(array: unknown[], itemToRemove: unknown): number {
    const index = array.findIndex((item) => item === itemToRemove);

    if (index > -1) {
      array.splice(index, 1);
    }

    return index;
  }
};
